/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionaryclient;

import dictionaryserver1.DictionaryServer;
import dictionaryserver1.DictionaryServerService;
import dictionaryserver1.Word;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Annabel
 */
public class DictionaryClient {

    /**
     * Main method invoking the question method which starts the if statement of
     * what the client would like to do.
     */
    public static void main(String[] args) {
        question();
    }

    /**
     * Question method.Asks the client which operations they would like to
     * perform.Depending on their answer, different methods are called upon.
     */
    public static void question() {
        DictionaryServerService service = new DictionaryServerService();
        DictionaryServer port = service.getDictionaryServerPort();
        System.out.println("'add', 'delete', 'update' or 'print'?");
        Scanner in = new Scanner(System.in);
        String userinput = in.nextLine();
        if (userinput.equals("add")) {
            System.out.println("You're adding a word");
            addWord();
            System.out.println("Word added!");

        } else if (userinput.equals("delete")) {
            System.out.println("You're deleting a word");
            removeWord();
            System.out.println("Word deleted!");
        } else if (userinput.equals("update")) {
            System.out.println("You're updating a word");
            //updateWord();
            System.out.println("Word updated!");
        } else if (userinput.equals("list")) {
            System.out.println("You're requesting a list");
           // printList();
        } else {
            System.out.println("You need to make a choice!");
            question();
        }
    }

    /**
     * Add word method.Called upon when the user inputs 'add'.It allows the user
     * to input a word and definition.
     */
    public static void addWord() {
        DictionaryServerService service = new DictionaryServerService();
        DictionaryServer port = service.getDictionaryServerPort();
        System.out.println("Enter a word: ");
        Scanner x = new Scanner(System.in);
        String word = x.nextLine();
        System.out.println("Enter a definition");
        Scanner y = new Scanner(System.in);
        String definition = y.nextLine();
        port.add(word, definition);
    }

    /**
     * Remove word method.Called upon when the user inputs 'delete'.It allows
     * the user to delete a word and its definition.
     */
    public static void removeWord() {
        DictionaryServerService service = new DictionaryServerService();
        DictionaryServer port = service.getDictionaryServerPort();
        System.out.println("Enter a word you want to delete: ");
        Scanner x = new Scanner(System.in);
        String word = x.nextLine();
        port.remove(word);
    }

    /**
     * Update word method.Allows the user to update the definition of a word.The
     * user enters the word, it's old definition and the one it would like to
     * change it to.
     */
    public static void updateWord() {
        DictionaryServerService service = new DictionaryServerService();
        DictionaryServer port = service.getDictionaryServerPort();
        System.out.println("Enter a word you want to update: ");
        Scanner x = new Scanner(System.in);
        String word = x.nextLine();
        System.out.println("Enter the old definition: ");
        Scanner y = new Scanner(System.in);
        String oldDef = y.nextLine();
        System.out.println("Enter the new definition: ");
        Scanner z = new Scanner(System.in);
        String newDef = z.nextLine();
        port.replace(word, oldDef, newDef);
    }

    /**
     * Print list method.Allows the user to input a list of words and it will
     * print their definitions.I however was stumped as to how to convert to 
     * List<String>.I had a google, but everything I found seemed to brake my 
     * even more.I tried casting to a String and using 'instance of' but 
     * couldn't use either in a way to benefit me.I've commented out those two 
     * lines so the code will still compile.
     */
     public static void printList() {
        DictionaryServerService service = new DictionaryServerService();
        DictionaryServer port = service.getDictionaryServerPort();
        System.out.println("Enter the words you want to see the definitions of ");
        Scanner x = new Scanner(System.in);
        String word2 = x.nextLine();
        //for (Word instanceword : DictionaryServer.dictLookUp(port)) {
            //System.out.println("Word: " + word.getWord() + " Definition: " + word.getDefinition());
            
        }
   

}
