/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionaryserver1;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Annabel Kimber
 */
@WebService
public class DictionaryServer {

    public DictionaryServer() {

    }
    //Declaring the variables for the HashMap so no magic numbers
    final int defaulInitialCapacity = 16; //16 means 16 shards before resizing
    final float defaultLoadFactor = 0.9f; //0.9 means if the buckets are more than 90% full, the map will be resized
    final int defaultConcurrencyLevel = 1; //1 means the estimated number of concurrently updating threads*/

    /**
     * I used a concurrent hash map because I believed it would be easier to
     * implement the synchronisation, however, I later was unable to implement
     * this fully, other than synchronising setting the words and definitions.I
     * still don't believe that I used the ConcurrentHashMap to it's full 
     * advantage and would probably have been better of using a HashTable and 
     * cloning to perform the synchronisation.
     */
    private ConcurrentHashMap<String, String> dictionaryDefinition = new ConcurrentHashMap<String, String>(defaulInitialCapacity,
            defaultLoadFactor,
            defaultConcurrencyLevel);

    /**
     * Creating a method that allows the user to remove words and their
     * definitions from the Dictionary stored within the ConcurrentHashMap.I
     * have added validation to check whether the word already exists or not.
     */
    public boolean remove(String key) {
        return dictionaryDefinition.remove(key, dictionaryDefinition.get(key));
    }

    /**
     * Creating a method that allows the user to add words to the Dictionary
     * stored within the ConcurrentHashMap.I have added validation to check
     * whether the word already exists or not.
     */
    public boolean add(String key, String value) {
        dictionaryDefinition.put(key, value);
        return value.equals(dictionaryDefinition.get(key));
    }

    /**
     * Creating a method that allows the user to remove words from the
     * Dictionary stored within the ConcurrentHashMap.There is no validation as
     * the word is already within the concurrentHashMap.
     */
    public boolean replace(String key, String oldValue, String newValue) {
        dictionaryDefinition.replace(oldValue, newValue);
        return oldValue.equals(dictionaryDefinition.get(key));
    }

    /**
     * Creating a method that allows the user to lookup a list words entered
     * from the Dictionary stored within the ConcurrentHashMap and get their
     * definitions.
     */
    public List<Word> dictLookUp(List<String> wordDef) {
        List<Word> wordList = new ArrayList<Word>();
        for (String word : wordDef) {
            wordList.add(new Word(word, dictionaryDefinition.get(word)));
        }
        return wordList;
    }
}
