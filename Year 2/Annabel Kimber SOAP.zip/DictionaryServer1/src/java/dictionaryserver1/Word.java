package dictionaryserver1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Annabel Kimber
 */
public class Word {

    //Constructor for the word class
    public Word(String word, String definition) {
        this.word = word;
        this.definition = definition;
    }
    //declaring my variables
    String word;
    String definition;

    //Getting and returning word
    public String getWord() {
        return word;
    }

    //Setting word
    public synchronized void setWord(String word) {
        this.word = word;
    }

    //Getting and returning definition
    public String getDefinition() {
        return definition;
    }

    //Setting definition
    public synchronized void setDefinition(String definition) {
        this.definition = definition;
    }

}
