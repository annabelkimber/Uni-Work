/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionaryclient;

/**
 *
 * @author Annabel
 */

//declaring my variables
public class Word {
    private String word;
    private String definition;
    
    //Constructor for the word class
    public Word (String w, String d) {
       setWord(w);
       setDefinition(d);
    }
    
    public Word(){ 
        
    }
    
    //Setting word
    public void setWord(String w) {
       word = w;
    }
    
    //Setting definition
    public void setDefinition(String d){
        definition = d;
    }
    
    //Getting and returing word
    public String getWord(){
        return word;
    }
    
    //Getting and returning Definition
    public String getDefinition(){
        return definition;
    }
    
    //Setting definition
    @Override
    public String toString(){
        return "Word: " +  word + ", Definition: " + definition;
    }
}
