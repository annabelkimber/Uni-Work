READ ME

To compile the code, right click on the 'Web Dictionary' package, and then click deploy. 
Once 'Web Dictionary' has been deployed, right click on 'DictionaryClient' and then click 
on Run. 
Once the program is running, follow the prompts. 